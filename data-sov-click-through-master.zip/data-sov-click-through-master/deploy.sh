aws s3 cp dist/ s3://datasovclickthrough/ --acl public-read --recursive
